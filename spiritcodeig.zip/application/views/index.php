<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Situs Penyedia Followers & Likes Instagram Gratis">
    <meta name="author" content="Cyberpassnet">
     <link rel="SHORTCUT ICON" href="http://3835642c2693476aa717-d4b78efce91b9730bcca725cf9bb0b37.r51.cf1.rackcdn.com/Instagram_App_Large_May2016_200.png">
    <title>Cyberpassnet Tools Auto Like</title>
    <link href="<?=base_url($list_config['base_css'])?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url($list_config['base_css'])?>/main-style.css" rel="stylesheet">
     <link href="<?=base_url($list_config['base_css'])?>/style.css" rel="stylesheet">
     <link href="<?=base_url($list_config['base_css'])?>/rtl.css" rel="stylesheet">
     <link href="<?=base_url($list_config['base_css'])?>/jutifiedGallery.min.css" rel="stylesheet">
    <link href="<?=base_url($list_config['base_fonts'])?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <?php if($allowed) print '
	<style>
	body {
	  padding-top: 80px;
	}
	.sorry {
	margin-bottom:5px;
	}
	}
.login-button{
	display: inline-block;
    text-decoration: none;
    padding: 15px 40px;
    border: 2px solid #fff;
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    margin: 20px 20px 10px 0;
    color: #fff;
    font-size: 16px;
	background-color: transparent;
	transition: border 0.25s linear 0s, color 0.25s linear 0s, background-color 0.25s linear 0s;
	font-weight: bold;
}
.login-button:focus,
.login-button:hover{
  border-color: #fff;
  color: #fff;
}
	</style>'; ?>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<script type="text/javascript">
if (typeof document.onselectstart!="undefined") {
document.onselectstart=new Function ("return false");
}
else{
document.onmousedown=new Function ("return false");
document.onmouseup=new Function ("return true");
}
</script>
<script type='text/javascript'>
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href="http://www.shafou.com/"});
//]]>
</script>
  <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
 <a href="#" class="navbar-brand"><i class="fa fa-instagram"></i> Cyberpassnet</a>        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><?=anchor('/', '<i class="glyphicon glyphicon-home"></i> Beranda')?></li>
            <li><a href="#myModal" data-toggle="modal" data-target="#myModal"><i class="glyphicon glyphicon-shopping-cart"></i> Beli Poin</a></li>
			<?php if(!$allowed) print '<li>'.anchor('masuk', '<i class="glyphicon glyphicon-off"></i> Masuk').'</li>'; ?>
          </ul>
		  <?php if($allowed): ?>
          <ul class="nav navbar-nav navbar-right">
			<li><?=anchor('#', '<i class="fa fa-credit-card"></i> Poin: '.$user->poin, array('id' => 'point'))?></li>
			<li><?=anchor('users/logout', '<i class="glyphicon glyphicon-off"></i> Keluar')?></li>
		  </ul>
		 <?php endif; ?>
        </div>
      </div>
    </nav>
<?php if(!$allowed): ?>
    </nav>
       <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner" role="listbox">
 <center>
 <br>
 	<img src="assets/images/cyberpassnet.png" width="200">
	  <h3 style="color: white;">Cyberpassnet Tool For Instagram.</h3>
	  <hr>
	  <div class="by docs-content">
	    <div class="row" style="color: white;">
          <div class="col-sm-4">
	        <img src="assets/images/safe.png" width="70">
            <h3>Informasi Anda Aman</h3>
            <p>Kami tidak menyimpan password anda, kami memerlukan password pada saat login agar tersambung dengan <strong>API</strong> untuk saling follow dan like tetapi tidak menyimpan password. <strong>Mengapa kami tidak menyimpan password?</strong> karena kami selalu menjaga kepercayaan Pengguna, kepercayaan adalah modal utama agar menjadi website auto followers dan likes Instagram gratis yang terbaik yang pernah ada. Terima kasih atas kepercayaan Anda kepada kami <strong>Cyberpassnet</strong>. </p>
          </div>
          <div class="col-sm-4">
	        <img src="assets/images/follower.png" width="70">
            <h3>Followers untuk apa?</h3>
            <p>Mempunyai banyak followers dan likes Instagram dapat meningkatkan <strong>kredibilitas, brand, maupun popularitas</strong> akun Instagram anda. Hal ini sangat berguna bagi Anda yang memiliki <strong>OLSHOP/Toko Online</strong> untuk <strong>menambah daya beli</strong> konsumen dan juga sebagai perbandingan banyaknya followers dan likes akun Instagram Anda dengan toko online lainnya. Followers dan Likes juga berguna bagi para <strong>Buzzer</strong> untuk meningkatkan <strong>jangkauan pemirsa</strong> di Instagram, sehingga akun Instagram anda dilirik sebagai promotor produk untuk iklan mereka. Mari bergabung di Cyberpassnet!.</p>
          </div>
          <div class="col-sm-4">
 	        <img src="assets/images/responsive.png" width="70">
            <h3>Tampilan Responsive</h3>
            <p>Menggunakan <strong>Bootstrap sebagai Framework CSS</strong>, membuat website ini mudah dan efisien pada tampilan. Mudah dibuka di Ponsel, Tablet dan Desktop tanpa harus membuka link yang berbeda.</p>
          </div>
	    </div>
	  </div>
	  </center>
	  <!-- Menu Pembayaran -->
	  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"> Beli Poin</h4>
      </div>
      <div class="modal-body">
                  <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th><center>Poin</th></center>
                        <th><center>Harga Via Pulsa</th></center>
                      </tr>
                    </thead>
                   <tbody>
                      <tr>
                        <td><center>10 Poin</td></center>
                        <td><center>Rp. 10.000 </td></center>
                    </tbody>
                      <tr>
                        <td><center>20 Poin</td></center>
                        <td><center>Rp. 15.000</td></center>
                      </tr>
                    </tbody>
                                <tr>
                        <td><center>30 Poin</td></center>
                        <td><center>Rp. 20.000</td></center>
                      </tr>
</tbody>
<tr>
                        <td><center>40 Poin</td></center>
                        <td><center>Rp. 25.000</td></center>
                      </tr>
                     </tbody>
                      <tr>
                        <td><center>80 Poin</td></center>
                        <td><center>Rp. 50.000</td></center>
                      </tr>
                      </tbody>
                      <td><center>100 Poin</td></center>
                      <td><center>Rp. 75.000</td></center>
                      </tr>
                   </tbody>
                     </tr>
                      </tbody>
                      <td><center>200 Poin</td></center>
                      <td><center>Rp. 100.000</td></center>
                      </tr>
                   </tbody>
          </tbody>
                  </table>
            <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th><center>Jenis Pembayaran</th></center>
                        <th><center>Tujuan Pembayaran</th></center>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><center><img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/83/Telkomsel_Logo.svg/1024px-Telkomsel_Logo.svg.png" height="50px;"></img></center></td>
                        <td><center>010101010101</td></center>
                      </tr>
                    </tbody>
                  </table>
                  <center><b>Hubungi saya :</b>
                  <br>
                <a href="https://www.instagram.com/mas_dahni/" button type="button" class="btn btn btn-info"><span class="fa fa-instagram"></span> Instagram</a>
                  <a href="mailto:spiritcode@cyberpassnet.com" button type="button" class="btn btn btn-info"><span class="fa fa-envelope"></span> spiritcode@cyberpassnet.com</a>
<br></center></br>
                        <div class="modal-footer">
        <button type="button" class="btn btn btn-info btn-block btn-flat" data-dismiss="modal">Tutup</button>           
 </div>  
        </div>
    </div>
</form>
</div>                     
</div>  
        <!-- Close menu pembayarn -->
                       <center style="color: white;"><i>&copy; 2018 Cyberpassnet, Inc. All Right Reserved.</i></center>
<br>
         </div>
     </div>
<?php else: ?>
	<div class="w3-container w3-content" style="max-width:1400px">
	<div class="w3-row">
	    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->   
        <div class="w3-card w3-round w3-white">                   
            <div class="w3-container">
				<h4 class="w3-center">
					<a class="compersation-one" href="profile/"><b><?=$user_data['account']->user->full_name?></b> (@<?=$user_data['account']->user->username?>)</a>
                </h4>
                <p class="w3-center"><img class="w3-circle" style="height:106px;width:106px" src="<?=$user_data['account']->user->profile_pic_url?>"></p>
              </a>
              <hr>
              <ul class="list-one text-center">
                <li class="ul-list">
                  <a class="compersation-one">
                    Post
                    <h5 class="slide"><b style="color:blue;"><?=$user_data['account']->user->media_count?></b></h5>
                  </a>
                </li>
                <li class="ul-list">
                  <a class="compersation-one">
                    Followers
                    <h5 class="slide"><b style="color:blue;" id="followers"><?=$user_data['account']->user->follower_count?></b></h5>
                  </a>
                </li>
                <li class="ul-list">
                  <a class="compersation-one">
                    Following
                    <h5 class="slide"><b style="color:blue;"><?=$user_data['account']->user->following_count?></b></h5>
                  </a>
                </li>
              </ul>
				<br>
				</div>
			</div>
				 <div class="w3-card w3-round">
        <div class="w3-white">
          <button id="getfollowers" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-user-plus"></i> Followers+</button>
            </div>
          <button id="getlikes" class="w3-button w3-block w3-theme-l1 w3-left-align"><i class="fa fa-heart"></i> Likes+s</button>      
      </div>
		</div>
        <div class="w3-col m7">
<div class="w3-row-padding">
        <div class="w3-col m12">
          <div class="w3-card w3-round w3-white">
            <div class="w3-container w3-padding">
                        <div class="panel-title">Peraturan dan Penggunaan Layanan</div>
                    </div> 
                    <div class="panel-body">
	<h2 class="text-center">PERATURAN</h2><hr>
       <ol>
   <li>
       Jangan mengunfollow sesama pengguna layanan ini.Cukup mention mereka untuk follback
   </li>
   <li>
		Jangan mem-Private akun anda,jika anda mem-Private akun anda,followers/like tidak akan bertambah.
   </li>
   <li>
		Layanan ini gratis,mohon gunakan layanan ini dengan bijak
   </li>
   <li>
       Use this tools at your own risk
   </li>
   <li>
       Ingat kami tidak pernah menyimpan password anda!,Kami hanya memerlukan password anda pada saat login untuk menghubungkan akun anda dengan API Instagram.
   </li>
       </ol><hr>
</div>
				</div>
        </div>
			</div>
		</div>
    <div class="w3-col m2">
      <div class="w3-card w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Cyberpassnet Team</p>
          <img src="assets/images/cyberpassnet.png" width="100%">
          <p><strong>Coded By SpiritCode</strong></p>
        </div>
      </div>
  </div>
    </div>
    <br>
    <br>
    <div id="menu"></div>
</div>
    	  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"> Beli Poin</h4>
      </div>
      <div class="modal-body">
                  <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th><center>Poin</th></center>
                        <th><center>Harga Via Pulsa</th></center>
                      </tr>
                    </thead>
                   <tbody>
                      <tr>
                        <td><center>10 Poin</td></center>
                        <td><center>Rp. 10.000 </td></center>
                    </tbody>
                      <tr>
                        <td><center>20 Poin</td></center>
                        <td><center>Rp. 15.000</td></center>
                      </tr>
                    </tbody>
                                <tr>
                        <td><center>30 Poin</td></center>
                        <td><center>Rp. 20.000</td></center>
                      </tr>
</tbody>
<tr>
                        <td><center>40 Poin</td></center>
                        <td><center>Rp. 25.000</td></center>
                      </tr>
                     </tbody>
                      <tr>
                        <td><center>80 Poin</td></center>
                        <td><center>Rp. 50.000</td></center>
                      </tr>
                      </tbody>
                      <td><center>100 Poin</td></center>
                      <td><center>Rp. 75.000</td></center>
                      </tr>
                   </tbody>
                     </tr>
                      </tbody>
                      <td><center>200 Poin</td></center>
                      <td><center>Rp. 100.000</td></center>
                      </tr>
                   </tbody>
          </tbody>
                  </table>
            <table id="example2" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th><center>Jenis Pembayaran</th></center>
                        <th><center>Tujuan Pembayaran</th></center>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><center><img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/83/Telkomsel_Logo.svg/1024px-Telkomsel_Logo.svg.png" height="50px;"></img></center></td>
                        <td><center>010101010101</td></center>
                      </tr>
                    </tbody>
                  </table>
                  <center><b>Hubungi saya :</b>
                  <br>
                <a href="https://www.instagram.com/mas_dahni/" button type="button" class="btn btn btn-info"><span class="fa fa-instagram"></span> Instagram</a>
                  <a href="mailto:spiritcode@cyberpassnet.com" button type="button" class="btn btn btn-info"><span class="fa fa-envelope"></span> spiritcode@cyberpassnet.com</a>
<br></center></br>
                        <div class="modal-footer">
        <button type="button" class="btn btn btn-info btn-block btn-flat" data-dismiss="modal">Tutup</button>           
 </div>  
        </div>
    </div>
</form>
</div>                     
</div>  
<?php endif; ?>
    <script src="<?=base_url($list_config['base_js'])?>/jquery.min.js"></script>
	<script>
/* wassup bruh? */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('$(1f).1i(6(){$("#j").17(6(){$.E({o:\'5/O\',G:l,I:\'H\',Y:\'X\',m:6(8){$("#j").h("3","3");$("#k").h("3","3");11(8.16){$("#O").7(8.O);$("#C").7(\'<i 1="4 4-1a-14"></i> 1c: \'+8.C);$("#5").7(\'<0 1="g-e-12"><0 1="2 2-m"><0 1="2-f"><0 1="2-d">q 1d</0></0><0 1="2-9">\'+8.v+\'</0></0></0>\')}1b $("#5").7(\'<0 1="g-e-12"><0 1="2 2-t"><0 1="2-f"><0 1="2-d">q..</0></0><0 1="2-9">\'+8.v+\'</0></0></0>\')},K:6(a,b,c){$("#j").h("3","3");$("#k").h("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-t"><0 1="2-f"><0 1="2-d">q..</0></0><0 1="2-9">\'+c+\'</0></0></0>\')},z:6(){$("#j").r("3","3");$("#k").r("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-Q"><0 1="2-f"><0 1="2-d">R..</0></0><0 1="2-9"><0 1="T"><0 1="u-U"><p><i 1="4 4-P 4-A 4-y 4-D x-B"></i></p><n S="L-N">M 19 15 O J..</n></0></0></0></0></0>\')}});w l});$("#k").17(6(){$.E({o:\'5/V\',G:l,I:\'H\',m:6(8){$("#j").h("3","3");$("#k").h("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-m"><0 1="2-f"><0 1="2-d">W 13</0></0><0 1="2-9">\'+8+\'</0></0></0>\')},K:6(a,b,c){$("#j").h("3","3");$("#k").h("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-t"><0 1="2-f"><0 1="2-d">q..</0></0><0 1="2-9">\'+c+\'</0></0></0>\')},z:6(){$("#j").r("3","3");$("#k").r("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-Q"><0 1="2-f"><0 1="2-d">R..</0></0><0 1="2-9"><0 1="T"><0 1="u-U"><p><i 1="4 4-P 4-A 4-y 4-D x-B"></i></p><n S="L-N">M Z s-s J..</n></0></0></0></0></0>\')}});w l})});6 1h(o,F,18){$.E({o:o,10:18+\'=\'+F,G:l,I:\'H\',m:6(8){$("#5").7(\'<0 1="g-e-12"><0 1="2 2-m"><0 1="2-f"><0 1="2-d">W 13</0></0><0 1="2-9">\'+8+\'</0></0></0>\')},K:6(a,b,c){$("#5").1e(o)},z:6(){$("#5").7(\'<0 1="g-e-12"><0 1="2 2-Q"><0 1="2-f"><0 1="2-d">R..</0></0><0 1="2-9"><0 1="T"><0 1="u-U"><p><i 1="4 4-P 4-A 4-y 4-D x-B"></i></p><n S="L-N">M Z s-s J..</n></0></0></0></0></0>\')}});w l}6 V(F){$.E({o:\'5/V\',10:\'1g=\'+F,G:l,I:\'H\',Y:\'X\',m:6(8){$("#j").h("3","3");$("#k").h("3","3");11(8.16){$("#C").7(\'<i 1="4 4-1a-14"></i> 1c: \'+8.C);$("#5").7(\'<0 1="g-e-12"><0 1="2 2-m"><0 1="2-f"><0 1="2-d">q 1d</0></0><0 1="2-9">\'+8.v+\'</0></0></0>\')}1b $("#5").7(\'<0 1="g-e-12"><0 1="2 2-t"><0 1="2-f"><0 1="2-d">q..</0></0><0 1="2-9">\'+8.v+\'</0></0></0>\')},K:6(a,b,c){$("#j").h("3","3");$("#k").h("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-t"><0 1="2-f"><0 1="2-d">q..</0></0><0 1="2-9">\'+c+\'</0></0></0>\')},z:6(){$("#j").r("3","3");$("#k").r("3","3");$("#5").7(\'<0 1="g-e-12"><0 1="2 2-Q"><0 1="2-f"><0 1="2-d">R..</0></0><0 1="2-9"><0 1="T"><0 1="u-U"><p><i 1="4 4-P 4-A 4-y 4-D x-B"></i></p><n S="L-N">M 19 15 V 1j s J..</n></0></0></0></0></0>\')}});w l}',62,82,'div|class|panel|disabled|fa|menu|function|html|hasil|body||||title|md|heading|col|removeAttr||getfollowers|getlikes|false|success|span|url||Hasil|attr|foto|warning|text|content|return|margin|3x|beforeSend|pulse|bottom|point|fw|ajax|id|timeout|POST|type|anda|error|help|Sedang|block|followers|spinner|info|Loading|clas|row|center|likes|Pilih|JSON|dataType|memuat|data|if||Foto|card|penambahan|result|click|add|memproses|credit|else|Poin|Coy|load|document|media_id|loadmore_|ready|pada'.split('|'),0,{}))
	</script>
    <script src="<?=base_url($list_config['base_js'])?>/bootstrap.min.js"></script>
  </body>
</html>